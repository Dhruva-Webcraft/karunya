// ============================================================
// Mock Data — Study Resources
// ============================================================

export const RESOURCES = [
  {
    id: 1,
    type: 'pdf',
    title: 'Introduction to Data Structures',
    author: 'Prof. Alan Kay',
    course: 'CS201',
    tags: ['Data Structures', 'Algorithms'],
    year: 2024,
    pages: 142,
    rating: 4.8,
  },
  {
    id: 2,
    type: 'note',
    title: 'Machine Learning Fundamentals — Week 4',
    author: 'Dr. Sarah Chen',
    course: 'AI301',
    tags: ['AI', 'ML', 'Python'],
    year: 2024,
    pages: 28,
    rating: 4.6,
  },
  {
    id: 3,
    type: 'journal',
    title: 'Attention Is All You Need — Annotated',
    author: 'Vaswani et al.',
    course: 'AI501',
    tags: ['AI', 'NLP', 'Transformers'],
    year: 2023,
    pages: 15,
    rating: 4.9,
  },
  {
    id: 4,
    type: 'pdf',
    title: 'Calculus III — Vector Fields & Surfaces',
    author: 'Prof. James Wilk',
    course: 'MATH301',
    tags: ['Mathematics', 'Calculus'],
    year: 2024,
    pages: 98,
    rating: 4.4,
  },
  {
    id: 5,
    type: 'note',
    title: 'Operating Systems — Memory Management',
    author: 'Dr. Priya Nair',
    course: 'CS304',
    tags: ['OS', 'Systems'],
    year: 2024,
    pages: 35,
    rating: 4.5,
  },
  {
    id: 6,
    type: 'journal',
    title: 'Graph Neural Networks: A Review',
    author: 'Zhou et al.',
    course: 'CS501',
    tags: ['AI', 'Graph Theory'],
    year: 2024,
    pages: 22,
    rating: 4.7,
  },
  {
    id: 7,
    type: 'pdf',
    title: 'Linear Algebra Essentials',
    author: 'Prof. Maria Santos',
    course: 'MATH201',
    tags: ['Mathematics', 'Linear Algebra'],
    year: 2024,
    pages: 180,
    rating: 4.8,
  },
  {
    id: 8,
    type: 'note',
    title: 'Database Design & SQL Mastery',
    author: 'Dr. Kevin Park',
    course: 'CS305',
    tags: ['Databases', 'SQL'],
    year: 2024,
    pages: 55,
    rating: 4.3,
  },
  {
    id: 9,
    type: 'journal',
    title: 'Quantum Computing: State of the Art',
    author: 'Harrow et al.',
    course: 'PHYS401',
    tags: ['Quantum', 'Physics'],
    year: 2024,
    pages: 18,
    rating: 4.6,
  },
];

export const TOPICS = ['All', 'Data Structures', 'AI', 'Mathematics', 'Systems', 'Databases', 'Quantum'];

export const GRADE_POINTS = {
  'A+': 4.0, 'A': 4.0, 'A-': 3.7,
  'B+': 3.3, 'B': 3.0, 'B-': 2.7,
  'C+': 2.3, 'C': 2.0, 'C-': 1.7,
  'D+': 1.3, 'D': 1.0, 'F': 0.0,
};

export const DAYS  = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
export const TIMES = ['8:00','9:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00'];

export const COLORS = ['#6366f1','#7c3aed','#059669','#d97706','#e11d48','#0284c7','#a855f7'];

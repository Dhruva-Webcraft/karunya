// ============================================================
// ResourceCard — displays a single study material
// ============================================================
import { motion } from 'framer-motion';
import { Download } from 'lucide-react';

const TYPE_META = {
  pdf:     { label: 'PDF',          cls: 'type-pdf',     icon: '📄' },
  note:    { label: 'Lecture Note', cls: 'type-note',    icon: '📝' },
  journal: { label: 'Journal',      cls: 'type-journal', icon: '🔬' },
};

export default function ResourceCard({ resource, index = 0 }) {
  const { label, cls, icon } = TYPE_META[resource.type];

  return (
    <motion.div
      className="resource-card"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05, duration: 0.35 }}
      whileHover={{ y: -4 }}
    >
      {/* Top row */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <span className={`resource-type ${cls}`}>{label}</span>
        <span style={{ fontSize: '0.75rem', color: 'var(--text3)', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
          <span style={{ color: '#f59e0b' }}>★</span> {resource.rating}
        </span>
      </div>

      {/* Icon */}
      <div style={{ fontSize: '1.75rem', margin: '0.6rem 0 0.6rem' }}>{icon}</div>

      {/* Title & Author */}
      <div className="resource-title">{resource.title}</div>
      <div style={{ fontSize: '0.8rem', color: 'var(--text3)', marginBottom: '0.75rem' }}>
        {resource.author} · {resource.course}
      </div>

      {/* Tags */}
      <div style={{ marginBottom: '0.75rem' }}>
        {resource.tags.map(t => <span key={t} className="tag tag-indigo">{t}</span>)}
      </div>

      {/* Footer */}
      <div className="resource-meta">
        <span>{resource.pages} pages</span>
        <span>·</span>
        <span>{resource.year}</span>
        <button
          style={{
            marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '0.3rem',
            background: 'none', border: 'none', color: 'var(--indigo2)',
            fontSize: '0.78rem', fontWeight: 600, cursor: 'pointer', padding: '0.2rem 0.5rem',
            borderRadius: 6, transition: 'background 0.15s',
          }}
          onMouseEnter={e => e.currentTarget.style.background = 'rgba(99,102,241,0.08)'}
          onMouseLeave={e => e.currentTarget.style.background = 'none'}
          onClick={() => alert(`Downloading: ${resource.title}`)}
        >
          <Download size={13} /> Save
        </button>
      </div>
    </motion.div>
  );
}

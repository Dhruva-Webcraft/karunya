// ============================================================
// RequestForm — validated form with confetti success animation
// ============================================================
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, CheckCircle } from 'lucide-react';

const COLORS = ['#6366f1','#7c3aed','#059669','#d97706','#e11d48','#0284c7','#a855f7'];

/* Confetti burst */
function Confetti() {
  const pieces = Array.from({ length: 35 }, (_, i) => ({
    id: i,
    left:     `${Math.random() * 100}%`,
    delay:    `${Math.random() * 0.7}s`,
    color:    COLORS[i % COLORS.length],
    size:     Math.random() * 8 + 4,
    duration: `${1.4 + Math.random() * 1.8}s`,
  }));
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none' }}>
      {pieces.map(p => (
        <div
          key={p.id}
          className="confetti-piece"
          style={{
            left: p.left, top: '-10px',
            animationDuration: p.duration, animationDelay: p.delay,
            background: p.color, width: p.size, height: p.size,
          }}
        />
      ))}
    </div>
  );
}

/* Validation */
function validate(form) {
  const e = {};
  if (!form.name.trim())                               e.name  = 'Full name is required';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Enter a valid email address';
  if (!form.course.trim())                             e.course = 'Course code is required';
  if (!form.type)                                      e.type  = 'Please select a resource type';
  if (!form.title.trim())                              e.title = 'Resource title is required';
  if (form.desc.length < 20)                           e.desc  = 'Please write at least 20 characters';
  return e;
}

const EMPTY = { name:'', email:'', course:'', type:'', title:'', desc:'', priority:'medium' };

export default function RequestForm() {
  const [form,    setForm]    = useState(EMPTY);
  const [errors,  setErrors]  = useState({});
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  /* Generic field change — clears that field's error */
  const change = key => e => {
    setForm(p => ({ ...p, [key]: e.target.value }));
    setErrors(p => ({ ...p, [key]: '' }));
  };

  const submit = () => {
    const errs = validate(form);
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setLoading(true);
    setTimeout(() => { setLoading(false); setSuccess(true); }, 1400);
  };

  if (success) return (
    <AnimatePresence>
      <div className="success-overlay">
        <motion.div
          className="success-card"
          initial={{ scale: 0.85, opacity: 0 }}
          animate={{ scale: 1,    opacity: 1 }}
          transition={{ type: 'spring', stiffness: 260, damping: 22 }}
        >
          <Confetti />
          <div style={{
            width: 72, height: 72, borderRadius: '50%', margin: '0 auto 1.25rem',
            background: 'rgba(5,150,105,0.10)', border: '1px solid rgba(5,150,105,0.25)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <CheckCircle size={34} color="var(--emerald)" />
          </div>
          <h2 style={{ fontFamily:'Syne,sans-serif', fontSize:'1.5rem', fontWeight:800, marginBottom:'0.5rem' }}>
            Request Submitted! 🎉
          </h2>
          <p style={{ color:'var(--text2)', marginBottom:'1.5rem', lineHeight:1.6 }}>
            Your resource request has been received. Our team will review and
            upload it within 48 hours.
          </p>
          <button
            className="btn-primary"
            style={{ justifyContent:'center', width:'100%' }}
            onClick={() => { setSuccess(false); setForm(EMPTY); }}
          >
            Submit Another Request
          </button>
        </motion.div>
      </div>
    </AnimatePresence>
  );

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
      {/* Name + Email */}
      <div className="form-grid">
        <div className="form-group">
          <label className="form-label">Full Name *</label>
          <input className="form-input" placeholder="John Smith" value={form.name} onChange={change('name')} />
          {errors.name && <div className="form-error">{errors.name}</div>}
        </div>
        <div className="form-group">
          <label className="form-label">Email Address *</label>
          <input className="form-input" type="email" placeholder="john@university.edu" value={form.email} onChange={change('email')} />
          {errors.email && <div className="form-error">{errors.email}</div>}
        </div>
      </div>

      {/* Course + Type */}
      <div className="form-grid">
        <div className="form-group">
          <label className="form-label">Course Code *</label>
          <input className="form-input" placeholder="CS301, MATH201..." value={form.course} onChange={change('course')} />
          {errors.course && <div className="form-error">{errors.course}</div>}
        </div>
        <div className="form-group">
          <label className="form-label">Resource Type *</label>
          <select className="form-select" value={form.type} onChange={change('type')}>
            <option value="">Select type...</option>
            <option value="pdf">PDF / Textbook</option>
            <option value="notes">Lecture Notes</option>
            <option value="journal">Research Paper</option>
            <option value="video">Video Lecture</option>
            <option value="other">Other</option>
          </select>
          {errors.type && <div className="form-error">{errors.type}</div>}
        </div>
      </div>

      {/* Title */}
      <div className="form-group">
        <label className="form-label">Resource Title *</label>
        <input className="form-input" placeholder="e.g. Introduction to Graph Theory — Chapter 5" value={form.title} onChange={change('title')} />
        {errors.title && <div className="form-error">{errors.title}</div>}
      </div>

      {/* Description */}
      <div className="form-group">
        <label className="form-label">Description / Context *</label>
        <textarea
          className="form-textarea"
          placeholder="Describe why this resource is valuable, what topic it covers, and where you found the reference..."
          value={form.desc}
          onChange={change('desc')}
        />
        {errors.desc && <div className="form-error">{errors.desc}</div>}
        <div style={{ fontSize:'0.75rem', color:'var(--text3)', marginTop:'0.25rem' }}>
          {form.desc.length} / 20 characters minimum
        </div>
      </div>

      {/* Priority */}
      <div className="form-group">
        <label className="form-label">Priority Level</label>
        <div style={{ display:'flex', gap:'0.5rem' }}>
          {[
            { k:'low',    c:'var(--emerald)', bg:'rgba(5,150,105,0.10)',  bd:'rgba(5,150,105,0.28)' },
            { k:'medium', c:'var(--amber)',   bg:'rgba(217,119,6,0.10)',   bd:'rgba(217,119,6,0.28)' },
            { k:'high',   c:'var(--rose)',    bg:'rgba(225,29,72,0.10)',   bd:'rgba(225,29,72,0.28)' },
          ].map(({ k, c, bg, bd }) => (
            <button
              key={k}
              onClick={() => setForm(f => ({ ...f, priority: k }))}
              style={{
                padding:'0.4rem 1rem', borderRadius:99, fontWeight:600, fontSize:'0.8rem',
                fontFamily:'DM Sans,sans-serif', transition:'all 0.15s', cursor:'pointer',
                background: form.priority===k ? bg    : 'white',
                color:      form.priority===k ? c     : 'var(--text2)',
                border:     `1px solid ${form.priority===k ? bd : 'var(--border)'}`,
              }}
            >
              {k.charAt(0).toUpperCase() + k.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Submit */}
      <button
        className="btn-primary"
        onClick={submit}
        disabled={loading}
        style={{ width:'100%', justifyContent:'center', padding:'0.875rem', fontSize:'0.95rem' }}
      >
        {loading ? (
          <span style={{ display:'flex', alignItems:'center', gap:'0.5rem' }}>
            <span style={{
              width:16, height:16, border:'2px solid rgba(255,255,255,0.35)',
              borderTopColor:'white', borderRadius:'50%',
              display:'inline-block', animation:'spin 0.8s linear infinite',
            }} />
            Submitting...
          </span>
        ) : (
          <><Send size={15} /> Submit Request</>
        )}
      </button>
    </motion.div>
  );
}

// ============================================================
// Navbar — sticky top navigation with animated tab indicator
// ============================================================
import { motion } from 'framer-motion';
import { Sparkles } from 'lucide-react';

const TABS = [
  { key: 'hub',     label: '📚 Hub' },
  { key: 'tools',   label: '🛠️ Tools' },
  { key: 'request', label: '✉️ Request' },
];

export default function Navbar({ tab, setTab }) {
  return (
    <nav className="nav">
      {/* Logo */}
      <motion.div
        className="nav-logo"
        initial={{ opacity: 0, x: -10 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.4 }}
      >
        Study<span>Nexus</span>
      </motion.div>

      {/* Tab Links */}
      <div className="nav-tabs">
        {TABS.map(({ key, label }) => (
          <button
            key={key}
            className={`nav-tab${tab === key ? ' active' : ''}`}
            onClick={() => setTab(key)}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Badge */}
      <motion.div
        className="nav-badge"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.3 }}
      >
        BETA
      </motion.div>
    </nav>
  );
}

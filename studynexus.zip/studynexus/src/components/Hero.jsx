// ============================================================
// Hero — landing section with animated stats and mini dashboard
// ============================================================
import { motion } from 'framer-motion';
import { BookOpen, Grid, Sparkles } from 'lucide-react';

const STATS = [
  { num: '142+', label: 'Study Materials' },
  { num: '3.87', label: 'Avg GPA Boost'   },
  { num: '12K',  label: 'Students Using'  },
  { num: '98%',  label: 'Satisfaction'    },
];

const MINI_CARDS = [
  { icon: '📊', label: 'GPA Tracker',  val: '3.87 GPA', sub: '↑ 0.12 this semester', color: '#6366f1' },
  { icon: '⏱️', label: 'Pomodoro',     val: '4 / 8',     sub: 'Sessions today',       color: '#059669' },
  { icon: '📚', label: 'Resources',    val: '142',        sub: 'Study materials',      color: '#d97706' },
  { icon: '🗓️', label: 'Next Class',   val: 'CS301',     sub: 'In 45 minutes',        color: '#0284c7' },
];

function HeroVisual() {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: 0.3, duration: 0.6 }}
      style={{ position: 'relative', padding: '1rem' }}
    >
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.85rem' }}>
        {MINI_CARDS.map((c, i) => (
          <motion.div
            key={i}
            className="glass"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 + i * 0.1 }}
            style={{ padding: '1rem', borderRadius: 14 }}
          >
            <div style={{ fontSize: '1.5rem', marginBottom: '0.4rem' }}>{c.icon}</div>
            <div style={{ fontSize: '0.68rem', color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 700 }}>
              {c.label}
            </div>
            <div style={{ fontFamily: 'Syne, sans-serif', fontSize: '1.1rem', fontWeight: 800, color: c.color, marginTop: '0.2rem' }}>
              {c.val}
            </div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text3)', marginTop: '0.1rem' }}>{c.sub}</div>
          </motion.div>
        ))}
      </div>
      {/* Decorative glow */}
      <div style={{
        position: 'absolute', top: -30, right: -30,
        width: 160, height: 160, borderRadius: '50%',
        background: 'radial-gradient(circle,rgba(99,102,241,0.15),transparent)',
        filter: 'blur(24px)', pointerEvents: 'none',
      }} />
    </motion.div>
  );
}

export default function Hero({ setTab }) {
  return (
    <div className="hero">
      {/* Left Copy */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="hero-eyebrow">
          <Sparkles size={13} /> Academic Excellence Platform
        </div>

        <h1 className="hero-title">
          Your <span className="gradient">Academic</span> Command Centre
        </h1>

        <p className="hero-desc">
          Access curated study materials, calculate your GPA, plan your schedule,
          and boost productivity — all in one beautifully designed workspace.
        </p>

        <div className="hero-btns">
          <button className="btn-primary" onClick={() => setTab('hub')}>
            <BookOpen size={16} /> Browse Resources
          </button>
          <button className="btn-outline" onClick={() => setTab('tools')}>
            <Grid size={16} /> Open Tools
          </button>
        </div>

        <div className="hero-stats">
          {STATS.map(({ num, label }) => (
            <motion.div
              key={label}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
            >
              <div className="stat-num">{num}</div>
              <div className="stat-label">{label}</div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Right Visual */}
      <HeroVisual />
    </div>
  );
}

// ============================================================
// ToolCard — bento-grid card that opens a tool modal
// ============================================================
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

export default function ToolCard({ tool, bentoClass, onClick, index = 0 }) {
  return (
    <motion.div
      className={`tool-card ${bentoClass}`}
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.07 }}
      onClick={onClick}
    >
      {/* Colour glow blob */}
      <div
        className="tool-glow"
        style={{ background: tool.color, top: -50, right: -50 }}
      />

      <div style={{ fontSize: '2.25rem', marginBottom: '0.75rem' }}>{tool.icon}</div>
      <div className="tool-name">{tool.name}</div>
      <div className="tool-desc">{tool.desc}</div>

      <div className="tool-arrow">
        <ArrowRight size={15} />
      </div>
    </motion.div>
  );
}

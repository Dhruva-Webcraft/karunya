// ============================================================
// NoteTaker — Markdown editor with live preview + localStorage
// ============================================================
import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Save, Check } from 'lucide-react';

const STORAGE_KEY = 'sn_notes_md';

const DEFAULT_MD = `# My Study Notes

Start typing here... **Bold**, *italic*, \`code\`

## Key Concepts
- First concept
- Second concept
- Third concept

## Summary
Write your summary here.

### Code Example
\`const gpa = calculateGPA(courses);\`
`;

/* Simple Markdown → HTML renderer */
function renderMd(text) {
  return text
    .replace(/^### (.+)$/gm, '<h3>$1</h3>')
    .replace(/^## (.+)$/gm,  '<h2>$1</h2>')
    .replace(/^# (.+)$/gm,   '<h1>$1</h1>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g,     '<em>$1</em>')
    .replace(/`(.+?)`/g,       '<code>$1</code>')
    .replace(/^- (.+)$/gm,     '<li>$1</li>')
    .replace(/(<li>[\s\S]*?<\/li>)/g, '<ul>$1</ul>')
    .split('\n\n')
    .map(block => block.startsWith('<') ? block : `<p>${block}</p>`)
    .join('');
}

/* Toolbar actions */
const TOOLBAR = [
  { label: 'Bold',     wrap: ['**', '**'] },
  { label: 'Italic',   wrap: ['*', '*']   },
  { label: '`Code`',   wrap: ['`', '`']   },
  { label: '# H1',     wrap: ['# ', '']   },
  { label: '## H2',    wrap: ['## ', '']  },
  { label: '- List',   wrap: ['- ', '']   },
];

export default function NoteTaker() {
  const [md,      setMd]      = useState(() => localStorage.getItem(STORAGE_KEY) || DEFAULT_MD);
  const [preview, setPreview] = useState(false);
  const [saved,   setSaved]   = useState(false);
  const taRef = useRef(null);

  useEffect(() => { localStorage.setItem(STORAGE_KEY, md); }, [md]);

  const save = () => { setSaved(true); setTimeout(() => setSaved(false), 2000); };

  const insertWrap = (prefix, suffix) => {
    const ta = taRef.current;
    if (!ta) return;
    const start = ta.selectionStart;
    const end   = ta.selectionEnd;
    const sel   = md.slice(start, end) || 'text';
    const next  = md.slice(0, start) + prefix + sel + suffix + md.slice(end);
    setMd(next);
    // Restore selection after React re-render
    requestAnimationFrame(() => {
      ta.focus();
      ta.setSelectionRange(start + prefix.length, start + prefix.length + sel.length);
    });
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      {/* Top controls */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'0.75rem' }}>
        <div className="tabs" style={{ flex:1, maxWidth:200, marginBottom:0 }}>
          <button className={`tab-btn${!preview ? ' active' : ''}`} onClick={() => setPreview(false)}>Edit</button>
          <button className={`tab-btn${ preview ? ' active' : ''}`} onClick={() => setPreview(true)}>Preview</button>
        </div>
        <button className="btn-add" onClick={save} style={{ marginLeft:'0.75rem' }}>
          {saved ? <><Check size={13} /> Saved!</> : <><Save size={13} /> Save</>}
        </button>
      </div>

      {!preview ? (
        <>
          {/* Toolbar */}
          <div className="notes-toolbar">
            {TOOLBAR.map(({ label, wrap }) => (
              <button key={label} className="notes-btn" onClick={() => insertWrap(wrap[0], wrap[1])}>
                {label}
              </button>
            ))}
          </div>
          {/* Editor */}
          <textarea
            ref={taRef}
            className="notes-area"
            value={md}
            onChange={e => setMd(e.target.value)}
            spellCheck="false"
          />
        </>
      ) : (
        /* Preview */
        <div
          className="notes-preview"
          dangerouslySetInnerHTML={{ __html: renderMd(md) }}
        />
      )}

      <div style={{ fontSize:'0.72rem', color:'var(--text3)', marginTop:'0.5rem' }}>
        {md.length} characters · Auto-saved to browser storage
      </div>
    </motion.div>
  );
}

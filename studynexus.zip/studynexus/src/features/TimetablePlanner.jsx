// ============================================================
// TimetablePlanner — click-to-add weekly schedule grid
// ============================================================
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Check } from 'lucide-react';
import { DAYS, TIMES, COLORS } from '../data/resources';

const STORAGE_KEY = 'sn_timetable';

function buildDefault() {
  const d = {};
  DAYS.forEach(day => TIMES.forEach(t => { d[`${day}-${t}`] = null; }));
  return d;
}

export default function TimetablePlanner() {
  const [schedule, setSchedule] = useState(() => {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || buildDefault(); }
    catch { return buildDefault(); }
  });
  const [editing, setEditing] = useState(null);           // key of cell being edited
  const [form,    setForm]    = useState({ name:'', room:'', color: COLORS[0] });

  useEffect(() => { localStorage.setItem(STORAGE_KEY, JSON.stringify(schedule)); }, [schedule]);

  const openCell = key => {
    const cur = schedule[key];
    setForm(cur || { name: '', room: '', color: COLORS[0] });
    setEditing(key);
  };

  const saveCell = () => {
    if (!form.name.trim()) { setEditing(null); return; }
    setSchedule(s => ({ ...s, [editing]: form }));
    setEditing(null);
  };

  const clearCell = (key, e) => {
    e.stopPropagation();
    setSchedule(s => ({ ...s, [key]: null }));
  };

  return (
    <div>
      <div style={{ overflowX: 'auto' }}>
        <div className="tt-grid" style={{ minWidth: 580 }}>
          {/* Headers */}
          <div className="tt-header" />
          {DAYS.map(d => <div key={d} className="tt-header">{d}</div>)}

          {/* Rows */}
          {TIMES.map(t => (
            <React.Fragment key={t}>
              <div className="tt-time">{t}</div>
              {DAYS.map(d => {
                const key  = `${d}-${t}`;
                const cell = schedule[key];
                return (
                  <div
                    key={key}
                    className={`tt-cell${cell ? ' filled' : ''}`}
                    style={cell ? { background: `${cell.color}12`, borderColor: `${cell.color}40` } : {}}
                    onClick={() => openCell(key)}
                  >
                    {cell ? (
                      <>
                        <div className="tt-cell-name" style={{ color: cell.color }}>{cell.name}</div>
                        {cell.room && <div className="tt-cell-room">{cell.room}</div>}
                        <button
                          className="btn-del"
                          style={{ position:'absolute', top:2, right:2, width:14, height:14, padding:0 }}
                          onClick={e => clearCell(key, e)}
                          title="Remove"
                        >
                          <X size={10} />
                        </button>
                      </>
                    ) : (
                      <div style={{ color:'var(--text3)', fontSize:'0.65rem', opacity:0.45, userSelect:'none' }}>+</div>
                    )}
                  </div>
                );
              })}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Edit modal */}
      <AnimatePresence>
        {editing && (
          <motion.div
            className="modal-overlay"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={() => setEditing(null)}
          >
            <motion.div
              className="modal modal-md"
              initial={{ scale: 0.92, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.92, opacity: 0 }}
              transition={{ type:'spring', stiffness:300, damping:28 }}
              onClick={e => e.stopPropagation()}
            >
              <button className="modal-close" onClick={() => setEditing(null)}><X size={15} /></button>
              <div className="modal-title">Add Class</div>
              <div className="modal-sub">{editing?.replace('-', ' — ')}</div>

              <div className="form-group">
                <label className="form-label">Class Name</label>
                <input
                  className="form-input"
                  placeholder="e.g. Computer Science 301"
                  autoFocus
                  value={form.name}
                  onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                  onKeyDown={e => e.key === 'Enter' && saveCell()}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Room / Location</label>
                <input
                  className="form-input"
                  placeholder="e.g. Room B204"
                  value={form.room}
                  onChange={e => setForm(f => ({ ...f, room: e.target.value }))}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Colour</label>
                <div style={{ display:'flex', gap:'0.5rem', flexWrap:'wrap' }}>
                  {COLORS.map(c => (
                    <button
                      key={c}
                      onClick={() => setForm(f => ({ ...f, color: c }))}
                      style={{
                        width:28, height:28, borderRadius:'50%', background:c, border:'none', cursor:'pointer',
                        outline: form.color === c ? `3px solid ${c}` : '3px solid transparent',
                        outlineOffset: 2, transition:'all 0.15s',
                      }}
                    />
                  ))}
                </div>
              </div>

              <div style={{ display:'flex', gap:'0.75rem', justifyContent:'flex-end', marginTop:'1.25rem' }}>
                <button className="btn-outline" onClick={() => setEditing(null)}>Cancel</button>
                <button className="btn-primary" onClick={saveCell}><Check size={14} /> Save</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// React needs to be in scope for JSX in CRA
import React from 'react';

// ============================================================
// PomodoroTimer — SVG ring progress, phases, session counter
// ============================================================
import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Play, Pause, RotateCcw } from 'lucide-react';

const PHASES = [
  { label: 'Focus',       min: 25, color: '#6366f1' },
  { label: 'Short Break', min: 5,  color: '#059669' },
  { label: 'Long Break',  min: 15, color: '#0284c7' },
];

const RADIUS   = 80;
const CIRCUM   = 2 * Math.PI * RADIUS;

export default function PomodoroTimer() {
  const [phaseIdx,  setPhaseIdx]  = useState(0);
  const [secs,      setSecs]      = useState(PHASES[0].min * 60);
  const [running,   setRunning]   = useState(false);
  const [sessions,  setSessions]  = useState(0);
  const timerRef = useRef(null);

  const phase   = PHASES[phaseIdx];
  const total   = phase.min * 60;
  const progress= 1 - secs / total;               // 0 → 1
  const offset  = CIRCUM * (1 - progress);

  /* Tick */
  useEffect(() => {
    if (running) {
      timerRef.current = setInterval(() => {
        setSecs(s => {
          if (s <= 1) {
            clearInterval(timerRef.current);
            setRunning(false);
            setSessions(n => n + 1);
            return 0;
          }
          return s - 1;
        });
      }, 1000);
    } else {
      clearInterval(timerRef.current);
    }
    return () => clearInterval(timerRef.current);
  }, [running]);

  const switchPhase = i => { setPhaseIdx(i); setSecs(PHASES[i].min * 60); setRunning(false); };
  const reset       = () => { setSecs(phase.min * 60); setRunning(false); };

  const mm = String(Math.floor(secs / 60)).padStart(2, '0');
  const ss = String(secs % 60).padStart(2, '0');

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      style={{ padding: '0.5rem' }}
    >
      {/* Phase selector */}
      <div className="pomo-phases">
        {PHASES.map((p, i) => (
          <button
            key={p.label}
            className={`pomo-phase-btn${phaseIdx === i ? ' active' : ''}`}
            onClick={() => switchPhase(i)}
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* SVG Ring */}
      <div className="pomo-ring">
        <svg width="180" height="180" viewBox="0 0 180 180">
          {/* Track */}
          <circle cx="90" cy="90" r={RADIUS} fill="none" stroke="#e2e8f0" strokeWidth="8" />
          {/* Progress */}
          <motion.circle
            cx="90" cy="90" r={RADIUS}
            fill="none" stroke={phase.color} strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={CIRCUM}
            strokeDashoffset={offset}
            style={{ transition: 'stroke-dashoffset 1s linear, stroke 0.4s' }}
          />
        </svg>
        <div className="pomo-time">
          <div className="pomo-num">{mm}:{ss}</div>
          <div className="pomo-phase-label" style={{ color: phase.color }}>{phase.label}</div>
        </div>
      </div>

      {/* Controls */}
      <div className="pomo-btns">
        <button className="pomo-btn pomo-btn-sec" onClick={reset} title="Reset">
          <RotateCcw size={16} />
        </button>
        <button
          className="pomo-btn pomo-btn-main"
          style={{ width: 58, height: 58, fontSize: '1.2rem', boxShadow: `0 4px 16px ${phase.color}44` }}
          onClick={() => setRunning(r => !r)}
        >
          {running ? <Pause size={20} fill="white" /> : <Play size={20} fill="white" />}
        </button>
        <button
          className="pomo-btn pomo-btn-sec"
          style={{ fontSize: '0.72rem', fontWeight: 700, fontFamily: 'Syne, sans-serif', minWidth: 44 }}
          title="Sessions completed"
        >
          {sessions}🍅
        </button>
      </div>

      <div style={{ textAlign: 'center', marginTop: '1.25rem', color: 'var(--text3)', fontSize: '0.8rem' }}>
        {sessions === 0
          ? 'Start your first focus session!'
          : `${sessions} session${sessions !== 1 ? 's' : ''} completed today 🎉`}
      </div>
    </motion.div>
  );
}

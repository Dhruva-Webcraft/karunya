// ============================================================
// GPACalculator — real-time GPA with localStorage persistence
// ============================================================
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Plus, X } from 'lucide-react';
import { GRADE_POINTS } from '../data/resources';

const STORAGE_KEY = 'sn_gpa_rows';

const defaultRows = () => [
  { id: 1, subject: 'Computer Science 301', credits: '3', grade: 'A'  },
  { id: 2, subject: 'Mathematics 201',      credits: '4', grade: 'B+' },
  { id: 3, subject: 'Physics 101',          credits: '3', grade: 'A-' },
];

export default function GPACalculator() {
  const [rows, setRows] = useState(() => {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || defaultRows(); }
    catch { return defaultRows(); }
  });

  /* Persist on change */
  useEffect(() => { localStorage.setItem(STORAGE_KEY, JSON.stringify(rows)); }, [rows]);

  /* Helpers */
  const addRow   = () => setRows(r => [...r, { id: Date.now(), subject: '', credits: '3', grade: 'B' }]);
  const removeRow = id => setRows(r => r.filter(x => x.id !== id));
  const update    = (id, field, val) => setRows(r => r.map(x => x.id === id ? { ...x, [field]: val } : x));

  /* GPA Calculation */
  const { gpa, totalCredits } = (() => {
    let pts = 0, cr = 0;
    rows.forEach(r => {
      const c = parseFloat(r.credits) || 0;
      const g = GRADE_POINTS[r.grade] ?? 0;
      pts += c * g; cr += c;
    });
    return { gpa: cr > 0 ? (pts / cr).toFixed(2) : '0.00', totalCredits: cr };
  })();

  const gpaNum   = parseFloat(gpa);
  const gpaColor = gpaNum >= 3.5 ? 'var(--emerald)' : gpaNum >= 2.5 ? 'var(--amber)' : 'var(--rose)';
  const gpaLabel = gpaNum >= 3.7 ? 'Summa Cum Laude' : gpaNum >= 3.5 ? 'Magna Cum Laude' : gpaNum >= 3.0 ? 'Cum Laude' : gpaNum >= 2.0 ? 'Satisfactory' : 'Needs Improvement';

  return (
    <div>
      {/* GPA Display */}
      <motion.div
        className="gpa-display"
        initial={{ opacity: 0, scale: 0.97 }}
        animate={{ opacity: 1, scale: 1 }}
      >
        <div className="gpa-number" style={{ color: gpaColor }}>{gpa}</div>
        <div style={{ color: 'var(--text2)', fontSize: '0.9rem', marginTop: '0.25rem' }}>{gpaLabel}</div>
        <div style={{ fontSize: '0.78rem', color: 'var(--text3)', marginTop: '0.2rem' }}>
          {totalCredits} credit hours · {rows.length} course{rows.length !== 1 ? 's' : ''}
        </div>
        <div className="gpa-bar">
          <motion.div
            className="gpa-fill"
            style={{ background: `linear-gradient(90deg,${gpaColor},${gpaColor}bb)` }}
            initial={{ width: 0 }}
            animate={{ width: `${(gpaNum / 4) * 100}%` }}
            transition={{ duration: 0.7, ease: 'easeOut' }}
          />
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.7rem', color: 'var(--text3)', marginTop: '0.35rem' }}>
          <span>0.0</span><span>2.0</span><span>3.0</span><span>4.0</span>
        </div>
      </motion.div>

      {/* Table */}
      <div style={{ overflowX: 'auto' }}>
        <table className="gpa-table">
          <thead>
            <tr>
              <th>Subject</th>
              <th>Credits</th>
              <th>Grade</th>
              <th>Quality Pts</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <motion.tr
                key={r.id}
                initial={{ opacity: 0, x: -6 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.04 }}
              >
                <td>
                  <input
                    className="gpa-input"
                    placeholder="Subject name"
                    value={r.subject}
                    onChange={e => update(r.id, 'subject', e.target.value)}
                  />
                </td>
                <td>
                  <input
                    className="gpa-input"
                    style={{ width: 64 }}
                    type="number"
                    min="1" max="6"
                    value={r.credits}
                    onChange={e => update(r.id, 'credits', e.target.value)}
                  />
                </td>
                <td>
                  <select
                    className="gpa-select"
                    value={r.grade}
                    onChange={e => update(r.id, 'grade', e.target.value)}
                  >
                    {Object.keys(GRADE_POINTS).map(g => <option key={g} value={g}>{g}</option>)}
                  </select>
                </td>
                <td style={{ color: 'var(--indigo2)', fontWeight: 700, fontSize: '0.875rem' }}>
                  {((parseFloat(r.credits) || 0) * (GRADE_POINTS[r.grade] ?? 0)).toFixed(1)}
                </td>
                <td>
                  <button className="btn-del" onClick={() => removeRow(r.id)} title="Remove row">
                    <X size={14} />
                  </button>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>

      <div style={{ marginTop: '1rem', display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
        <button className="btn-add" onClick={addRow}>
          <Plus size={14} /> Add Subject
        </button>
        <span style={{ fontSize: '0.78rem', color: 'var(--text3)' }}>
          Data auto-saved to your browser
        </span>
      </div>
    </div>
  );
}

// ============================================================
// App.js — root component, routing between Hub / Tools / Request
// ============================================================
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

import './index.css';
import { RESOURCES, TOPICS } from './data/resources';

import Navbar       from './components/Navbar';
import Hero         from './components/Hero';
import ResourceCard from './components/ResourceCard';
import ToolCard     from './components/ToolCard';
import RequestForm  from './components/RequestForm';

import GPACalculator   from './features/GPACalculator';
import TimetablePlanner from './features/TimetablePlanner';
import PomodoroTimer   from './features/PomodoroTimer';
import NoteTaker       from './features/NoteTaker';

// ---- Tool definitions ----------------------------------------
const TOOLS = [
  {
    id:   'gpa',
    name: 'GPA Calculator',
    desc: 'Track your academic performance in real-time. Add subjects, credits, and grades for instant GPA calculation with colour-coded results.',
    icon:  '🎓',
    color: '#6366f1',
    size:  'bento-1',
  },
  {
    id:   'timetable',
    name: 'Timetable Planner',
    desc: 'Build your weekly class schedule. Click any time slot to add a class with a custom colour. Saved automatically.',
    icon:  '📅',
    color: '#7c3aed',
    size:  'bento-2',
  },
  {
    id:   'pomodoro',
    name: 'Pomodoro Timer',
    desc: 'Boost focus with structured 25-minute work intervals and short breaks.',
    icon:  '🍅',
    color: '#e11d48',
    size:  'bento-3',
  },
  {
    id:   'notes',
    name: 'Markdown Notes',
    desc: 'Write rich notes with live Markdown preview.',
    icon:  '📝',
    color: '#059669',
    size:  'bento-4',
  },
];

// ---- Skeleton loader -----------------------------------------
function SkeletonGrid() {
  return (
    <div className="resources-grid">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="skeleton" style={{ height: 200 }} />
      ))}
    </div>
  );
}

// ---- Tool Modal ----------------------------------------------
function ToolModal({ tool, onClose }) {
  const Content = {
    gpa:       GPACalculator,
    timetable: TimetablePlanner,
    pomodoro:  PomodoroTimer,
    notes:     NoteTaker,
  }[tool.id];

  return (
    <AnimatePresence>
      <motion.div
        className="modal-overlay"
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        onClick={onClose}
      >
        <motion.div
          className="modal modal-lg"
          initial={{ scale: 0.93, opacity: 0, y: 12 }}
          animate={{ scale: 1,    opacity: 1, y: 0 }}
          exit={{    scale: 0.93, opacity: 0, y: 12 }}
          transition={{ type: 'spring', stiffness: 280, damping: 26 }}
          onClick={e => e.stopPropagation()}
        >
          {/* Close */}
          <button className="modal-close" onClick={onClose}><X size={15} /></button>

          {/* Header */}
          <div style={{ display:'flex', alignItems:'center', gap:'0.75rem', marginBottom:'0.25rem' }}>
            <span style={{ fontSize:'2.25rem' }}>{tool.icon}</span>
            <div>
              <div className="modal-title" style={{ marginBottom:0 }}>{tool.name}</div>
              <div style={{ color:'var(--text2)', fontSize:'0.85rem' }}>{tool.desc}</div>
            </div>
          </div>
          <div className="divider" />

          {/* Feature content */}
          {Content && <Content />}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// ---- Main App ------------------------------------------------
export default function App() {
  const [tab,         setTab]        = useState('hub');
  const [activeTool,  setActiveTool] = useState(null);
  const [search,      setSearch]     = useState('');
  const [activeTopic, setActiveTopic]= useState('All');
  const [loading,     setLoading]    = useState(true);

  // Simulate data loading
  useEffect(() => { const t = setTimeout(() => setLoading(false), 700); return () => clearTimeout(t); }, []);

  // Filter resources
  const filtered = RESOURCES.filter(r => {
    const q    = search.toLowerCase();
    const matchSearch = !q || r.title.toLowerCase().includes(q) || r.tags.some(t => t.toLowerCase().includes(q)) || r.author.toLowerCase().includes(q);
    const matchTopic  = activeTopic === 'All' || r.tags.some(t => t.toLowerCase().includes(activeTopic.toLowerCase()));
    return matchSearch && matchTopic;
  });

  return (
    <div>
      <div className="mesh" />

      {/* ---- Navigation ---- */}
      <Navbar tab={tab} setTab={t => { setTab(t); window.scrollTo({ top:0, behavior:'smooth' }); }} />

      {/* ---- Study Hub ---- */}
      {tab === 'hub' && (
        <>
          <Hero setTab={setTab} />

          <section className="section">
            <div className="section-header">
              <div className="section-label">Study Materials</div>
              <h2 className="section-title">Dynamic Study Hub</h2>
              <p className="section-sub">Curated PDFs, lecture notes, and academic journals — searchable and filterable.</p>
            </div>

            {/* Search */}
            <div className="search-wrap">
              <span className="search-icon">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
                </svg>
              </span>
              <input
                className="search-input"
                placeholder="Search by title, topic, author, or keyword..."
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>

            {/* Topic chips */}
            <div className="chips">
              {TOPICS.map(t => (
                <button
                  key={t}
                  className={`chip${activeTopic === t ? ' active' : ''}`}
                  onClick={() => setActiveTopic(t)}
                >
                  {t}
                </button>
              ))}
            </div>

            {/* Results count */}
            {!loading && (
              <div style={{ fontSize:'0.8rem', color:'var(--text3)', marginBottom:'1rem' }}>
                Showing <strong style={{ color:'var(--text)' }}>{filtered.length}</strong> result{filtered.length !== 1 ? 's' : ''}
                {activeTopic !== 'All' && <> in <span style={{ color:'var(--indigo2)', fontWeight:600 }}>{activeTopic}</span></>}
                {search && <> matching "<span style={{ color:'var(--indigo2)' }}>{search}</span>"</>}
              </div>
            )}

            {/* Grid */}
            {loading ? (
              <SkeletonGrid />
            ) : filtered.length > 0 ? (
              <div className="resources-grid">
                {filtered.map((r, i) => <ResourceCard key={r.id} resource={r} index={i} />)}
              </div>
            ) : (
              <motion.div
                initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                style={{ textAlign:'center', padding:'4rem 2rem', color:'var(--text3)' }}
              >
                <div style={{ fontSize:'3.5rem', marginBottom:'1rem' }}>🔍</div>
                <div style={{ fontWeight:700, fontSize:'1.1rem', color:'var(--text2)' }}>No resources found</div>
                <div style={{ fontSize:'0.875rem', marginTop:'0.4rem' }}>Try a different search term or select a different topic</div>
                <button className="btn-outline" style={{ marginTop:'1.25rem' }} onClick={() => { setSearch(''); setActiveTopic('All'); }}>
                  Clear Filters
                </button>
              </motion.div>
            )}
          </section>
        </>
      )}

      {/* ---- Tools ---- */}
      {tab === 'tools' && (
        <section className="section">
          <div className="section-header">
            <div className="section-label">Interactive Tools</div>
            <h2 className="section-title">Academic Toolkit</h2>
            <p className="section-sub">Everything you need to excel — GPA tracking, scheduling, focus timers, and note-taking.</p>
          </div>

          <div className="bento">
            {TOOLS.map((t, i) => (
              <ToolCard
                key={t.id}
                tool={t}
                bentoClass={t.size}
                index={i}
                onClick={() => setActiveTool(t)}
              />
            ))}

            {/* Coming Soon Card */}
            <motion.div
              className="tool-card bento-5"
              initial={{ opacity:0, y:12 }} animate={{ opacity:1, y:0 }} transition={{ delay:0.3 }}
              style={{
                background: 'linear-gradient(135deg,rgba(99,102,241,0.05),rgba(124,58,237,0.05))',
                border: '1px solid rgba(99,102,241,0.18)',
                cursor: 'default', alignItems:'center', justifyContent:'center', textAlign:'center',
              }}
            >
              <div style={{ fontSize:'2rem', marginBottom:'0.5rem' }}>🎯</div>
              <div className="tool-name">More Tools Coming Soon</div>
              <div className="tool-desc" style={{ maxWidth:320, margin:'0 auto' }}>
                Citation generator, plagiarism checker, formula sheets, and flashcards are in development.
              </div>
              <div style={{ display:'flex', gap:'0.5rem', marginTop:'1rem', justifyContent:'center', flexWrap:'wrap' }}>
                {['Citation', 'Flashcards', 'Formula Sheet', 'Plagiarism Check'].map(l => (
                  <span key={l} className="badge badge-indigo">{l}</span>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Modal */}
          {activeTool && <ToolModal tool={activeTool} onClose={() => setActiveTool(null)} />}
        </section>
      )}

      {/* ---- Request ---- */}
      {tab === 'request' && (
        <section className="section">
          <div className="section-header" style={{ textAlign:'center', maxWidth:560, margin:'0 auto 2.5rem' }}>
            <div className="section-label" style={{ justifyContent:'center' }}>Resource Requests</div>
            <h2 className="section-title">Can't Find What You Need?</h2>
            <p className="section-sub">Submit a request and our team will source or upload the material within 48 hours. We accept PDFs, papers, lecture notes, and more.</p>
          </div>

          <div className="glass" style={{ padding:'2.5rem', maxWidth:660, margin:'0 auto', borderRadius:20 }}>
            <RequestForm />
          </div>
        </section>
      )}

      {/* ---- Footer ---- */}
      <footer className="footer">
        <div style={{ marginBottom:'0.4rem' }}>
          <span style={{ fontFamily:'Syne,sans-serif', fontWeight:800, fontSize:'1.1rem' }}>
            Study<span style={{ color:'var(--indigo2)' }}>Nexus</span>
          </span>
        </div>
        <div>Built for students, by students · {new Date().getFullYear()} · All data saved locally in your browser</div>
      </footer>
    </div>
  );
}

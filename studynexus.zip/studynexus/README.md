# 📚 StudyNexus — Student Resource Hub

A modern, light-themed academic companion built with React.js.

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start the development server
npm start
```

Then open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 🗂️ Project Structure

```
studynexus/
├── public/
│   └── index.html              # HTML entry point
├── src/
│   ├── components/
│   │   ├── Navbar.jsx          # Sticky top navigation
│   │   ├── Hero.jsx            # Landing hero section
│   │   ├── ResourceCard.jsx    # Study material card
│   │   ├── ToolCard.jsx        # Bento grid tool card
│   │   └── RequestForm.jsx     # Validated request form + confetti
│   ├── features/
│   │   ├── GPACalculator.jsx   # Real-time GPA calculator (localStorage)
│   │   ├── TimetablePlanner.jsx# Weekly schedule grid (localStorage)
│   │   ├── PomodoroTimer.jsx   # SVG ring timer with phases
│   │   └── NoteTaker.jsx       # Markdown editor with live preview
│   ├── data/
│   │   └── resources.js        # Mock data & constants
│   ├── App.js                  # Root component & routing
│   └── index.css               # Light theme global styles
└── package.json
```

## ✨ Features

| Feature | Details |
|---|---|
| **Study Hub** | 9 mock resources (PDFs, Notes, Journals) with search + topic filters |
| **GPA Calculator** | Add/remove subjects, real-time GPA, colour-coded standing, localStorage |
| **Timetable Planner** | Mon–Fri 8am–5pm grid, custom colours, localStorage |
| **Pomodoro Timer** | SVG ring, Focus / Short Break / Long Break phases, session counter |
| **Markdown Notes** | Toolbar shortcuts, Edit/Preview toggle, localStorage |
| **Request Form** | 7-field validation, priority picker, loading spinner, confetti success |

## 🎨 Design

- **Fonts**: Syne (headings) + DM Sans (body)  
- **Theme**: Light — white surfaces, soft indigo accents, subtle gradients  
- **Motion**: Framer Motion for page transitions, modal springs, card lifts  
- **Storage**: All user data (GPA rows, timetable, notes) persists in localStorage

## 📦 Dependencies

- `react` 18, `react-dom` 18
- `framer-motion` 11
- `lucide-react` 0.383
- `react-scripts` 5 (CRA)
